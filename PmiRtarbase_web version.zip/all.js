
document.onkeypress=function(event){
    if(event.keyCode==13)return false;
};
$(document).ready(function(){

});




 