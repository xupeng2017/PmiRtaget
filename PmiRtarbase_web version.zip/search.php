<?
class search
{

    private $db;

    public function __construct() {

        $servername = "bdm721864299.my3w.com";
        $username = "bdm721864299";
        $password = "Cj20150702";
        $port = "3306";
        $db = "bdm721864299_db";

        $this->db = new mysqli($servername, $username, $password, $db, $port); // 创建数据库对象
        
        header('Access-Control-Allow-Origin:*'); // 允许所有来源
        header('Access-Control-Allow-Method:GET, POST'); // 允许访问的方式
        header('Content-Type:application/json'); // 返回数据 json格式
    }


    // 用于判断post参数是否存在SQL注入的风险
    // 返回值  true：参数安全，没有SQL注入的风险
    //         false: 参数包含SQL注入风险
    private function check_param($value=null) { 
        #  select|insert|update|delete|\'|\/\*|\*|\.\.\/|\.\/|union|into|load_file|outfile
    $str = '/select|insert|and|or|update|delete|\'|\/\*|\*|\.\.\/|\.\/|union|into|load_file|outfile/';

    if(!$value) {
        // exit('没有参数！');
        return true;

    }elseif(preg_match($str, $value)) { 

        return false;
        // exit('参数非法！');

    }
    return true; 
}

    public function run() {
        try {

            $param_miRNA = $this->check_param($_POST['miRNA']);
            $param_Target_gene = $this->check_param($_POST['Target_gene']);

            if($param_miRNA && $param_Target_gene) {
            $sql = 'select miRNA,Target_gene,Species,Conditional,Description,Year,PMID from 
            select_RNA where miRNA Like "%'.$_POST['miRNA'].'%" and Target_gene Like "%'.$_POST['Target_gene'].'%"' ;
                $result = [];
                // $result[] = ['flag'=> 'ok'];
                $results = $this->db->query($sql);
                
                if($results->num_rows>0) {
                    while($row=$results->fetch_assoc()) {
                        $result[] = $row;
                    }
                    // echo($result);  // 调试数据
                    echo json_encode($result);
                    return false;
                }
                // $result[] = ['file'=>'result20191227042817217133.xls'];
                // echo json_encode($result);
                return false;
            }
            
            echo json_encode([]);
            return false;
        } catch (Exception $e) {
            echo json_encode([$e->getMessage()]);
            return false;
        }
    }
}

$app = new search();
$re = $app->run();